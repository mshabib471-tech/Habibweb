<?php
function loadProxiesFromFile($filename) {
    $proxies = [];
    if (file_exists($filename)) {
        $lines = file($filename, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            list($ip, $port, $username, $password) = explode(':', $line);
            $proxies[] = "socks5://$username:$password@$ip:$port";
        }
    }
    return $proxies;
}

function getRandomProxy(&$proxies) {
    return $proxies[array_rand($proxies)];
}

function call($phone, &$proxies) {
    if (substr($phone, 0, 1) === '0') {
        $phone = substr($phone, 1);
    }

    $data = [
        "country_code" => "880",
        "uname" => "",
        "langCountry" => "bn-bd",
        "sendType" => "mobile",
        "currency" => "BDT",
        "language" => "bn",
        "mobileno" => $phone
    ];

    $url = "https://www.jayabaji.life/api/user/request-register-tac";
    $proxy = getRandomProxy($proxies);

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json'
    ]);
    curl_setopt($ch, CURLOPT_PROXY, $proxy);
    curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5); // Specify SOCKS5 proxy type

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        $error_msg = curl_error($ch);
        curl_close($ch);
        return "Error: " . $error_msg;
    }

    curl_close($ch);

    return $response ?: "Error: No response received.";
}

$proxyList = loadProxiesFromFile('proxy.txt'); // Load proxies from proxy.txt
$result = [];

header('Content-type: application/json; charset: utf-8');

if (empty($proxyList)) {
    $result['status'] = false;
    $result['msg'] = 'No valid proxies found.';
} elseif (isset($_REQUEST['phone']) && !empty($_REQUEST['phone'])) {
    $call_response = call($_REQUEST['phone'], $proxyList);
    $result = json_decode($call_response, true);
} else {
    $result['status'] = false;
    $result['msg'] = 'num are missing!';
}

echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
?>