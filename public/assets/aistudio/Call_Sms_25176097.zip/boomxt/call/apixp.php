<?php
$loginUrl = 'https://www.90jilivip.bar/wps/v2/verification/login';
$loginData = json_encode([
    "username" => "your_username", // Replace with your username
    "password" => "your_password"  // Replace with your password
]);

$loginCh = curl_init($loginUrl);
curl_setopt($loginCh, CURLOPT_RETURNTRANSFER, true);
curl_setopt($loginCh, CURLOPT_POST, true);
curl_setopt($loginCh, CURLOPT_POSTFIELDS, $loginData);
curl_setopt($loginCh, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'User-Agent: Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
]);

$loginResponse = curl_exec($loginCh);
$httpCode = curl_getinfo($loginCh, CURLINFO_HTTP_CODE);
$loginError = curl_error($loginCh);
curl_close($loginCh);

if ($loginError) {
    echo "Login Error: $loginError";
    exit;
}

echo "HTTP Code: $httpCode\n";
echo "Login Response: $loginResponse\n";
