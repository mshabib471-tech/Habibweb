<?php

$phoneNumber = $_REQUEST["phone"]; // Retrieve phone number from request

$url = "https://developer.quizgiri.xyz/api/v2.0/send-otp";

$curl = curl_init($url);
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

$headers = array(
    "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/109.0",
    "Content-Type: application/json",
);
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

$payload = array(
    "phone" => $phoneNumber, // Using the phone number retrieved from request
    "country_code" => "+880",
    "fcm_token" => null
);

$data = json_encode($payload);

curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

// For debug purposes only!
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

$response = curl_exec($curl);
curl_close($curl);

echo $response;

?>
