<?php

$phone = $_REQUEST["phone"]; // Fetching phone number from request
$url = "https://edge.ali2bd.com/api/consumer/v1/auth/login"; // URL to send the request to

$curl = curl_init($url);
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

$headers = array(
    "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Content-Type: application/json",
    "accept: application/json, text/plain, */*",
    "accept-language: en-US,en;q=0.9,ru;q=0.8",
    "origin: https://ali2bd.com",
    "priority: u=1, i",
    "referer: https://ali2bd.com/",
    "sec-ch-ua: \"Chromium\";v=\"124\", \"Google Chrome\";v=\"124\", \"Not-A.Brand\";v=\"99\"",
    "sec-ch-ua-mobile: ?0",
    "sec-ch-ua-platform: \"Windows\"",
    "sec-fetch-dest: empty",
    "sec-fetch-mode: cors",
    "sec-fetch-site: same-site",
);

curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

$data = json_encode(array(
    "username" => "+88" . $phone
));

curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

// Disable SSL verification (for debug only, not recommended for production)
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

$response = curl_exec($curl);

curl_close($curl);

echo $response;
?>
