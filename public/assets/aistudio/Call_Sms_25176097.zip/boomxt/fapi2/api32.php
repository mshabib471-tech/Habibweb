<?php

$phoneNumber = $_REQUEST["phone"]; // Get phone number from request

$url = "https://api.kormi24.com/graphql";

$curl = curl_init($url);
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

$headers = array(
    "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Content-Type: application/json",
    "accept: */*",
    "accept-language: en-US,en;q=0.9,ru;q=0.8",
    "authorization: tok",
    "origin: https://www.kormi24.com",
    "priority: u=1, i",
    "referer: https://www.kormi24.com/",
    "sec-ch-ua: ^\"Chromium^\";v=^\"124^\", ^\"Google Chrome^\";v=^\"124^\", ^\"Not-A.Brand^\";v=^\"99^\"",
    "sec-ch-ua-mobile: ?0",
    "sec-ch-ua-platform: ^\"Windows^\"",
    "sec-fetch-dest: empty",
    "sec-fetch-mode: cors",
    "sec-fetch-site: same-site"
);

curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

$data = array(
    "operationName" => "sendOTP",
    "variables" => array(
        "type" => 1,
        "mobile" => $phoneNumber,
        "additional" => "{\"user_agent\":\"web\",\"mobile\":\"" . $phoneNumber . "\"}"
    ),
    "query" => "mutation sendOTP(\$mobile: String!, \$type: Int!, \$additional: String) {
  sendOTP(mobile: \$mobile, type: \$type, additional: \$additional) {
    status
    message
    __typename
  }
}"
);

$json_data = json_encode($data);

curl_setopt($curl, CURLOPT_POSTFIELDS, $json_data);

// Set these options only for debugging, remove them in production
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

$response = curl_exec($curl);
curl_close($curl);
echo $response;

?>
